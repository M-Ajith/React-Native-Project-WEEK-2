export default color = {
  primary: "#fc5c65",
  secondary: "#4ECDC4",
};
